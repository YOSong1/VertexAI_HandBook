"""
PDF 멀티모달 콘텐츠 분석기 - 텍스트, 표, 이미지를 통합 분석
"""
import os
import re
import sys
from datetime import datetime
from PIL import Image
import google.generativeai as genai

from pdf_extract import extract_text_from_pdf
from pdf_gemini_vision import analyze_pdf_images_with_gemini
from pdf_table_gemini_analyzer import analyze_pdf_tables_with_gemini


def classify_image_type(image_path):
    """이미지 유형을 자동 분류합니다 (chart, diagram, photo, unknown)."""
    try:
        img = Image.open(image_path)
        width, height = img.size
        aspect_ratio = width / height if height > 0 else 1

        if aspect_ratio > 2.5 or aspect_ratio < 0.4:
            return "chart"
        elif 0.8 <= aspect_ratio <= 1.2:
            return "diagram"
        else:
            return "photo"
    except Exception as e:
        print(f"이미지 유형 분류 실패: {e}")
        return "unknown"


def analyze_content_type(text_content, threshold=0.7):
    """텍스트 콘텐츠의 유형을 분석합니다 (financial, technical, academic, business, general)."""
    if not text_content:
        return {"type": "empty", "confidence": 1.0}

    patterns = {
        "financial": [
            r'\$[\d,]+\.?\d*',
            r'\d{1,3}(,\d{3})*\.?\d*',
            r'(revenue|profit|loss|income|expense)',
            r'(q[1-4]|quarter|annual|year)',
        ],
        "technical": [
            r'(algorithm|function|method|class)',
            r'\b[A-Z]{2,}\b',
            r'(process|system|architecture)',
            r'\d+\.\d+\.\d+',
        ],
        "academic": [
            r'(abstract|introduction|methodology|conclusion)',
            r'\[\d+\]|\(\d{4}\)',
            r'(et al\.|ibid\.|cf\.)',
            r'(hypothesis|theorem|proof)',
        ],
        "business": [
            r'(strategy|market|customer|product)',
            r'(meeting|agenda|minutes)',
            r'(project|deadline|milestone)',
        ]
    }

    scores = {}
    for content_type, type_patterns in patterns.items():
        matches = sum(1 for p in type_patterns if re.search(p, text_content, re.IGNORECASE))
        scores[content_type] = matches / len(type_patterns) if type_patterns else 0

    best_type = max(scores.items(), key=lambda x: x[1])
    return {
        "type": best_type[0] if best_type[1] >= threshold else "general",
        "confidence": best_type[1],
        "all_scores": scores
    }


def generate_integrated_analysis(text_content, table_analyses, image_analyses, api_key=None):
    """텍스트, 표, 이미지 분석 결과를 통합하여 종합 인사이트를 생성합니다."""
    content_type = analyze_content_type(text_content)

    integration_prompt = f"""
    다음은 PDF 문서의 다양한 구성 요소에 대한 분석 결과입니다.
    이를 통합하여 종합적인 인사이트를 제공해주세요:

    === 문서 유형 분석 ===
    유형: {content_type['type']}
    신뢰도: {content_type['confidence']:.2f}

    === 텍스트 콘텐츠 (요약) ===
    {text_content[:1000]}...

    === 표 분석 결과 ===
    """

    if table_analyses:
        for table_name, analysis in table_analyses.items():
            integration_prompt += f"\n{table_name}: {analysis['analysis'][:300]}..."
    else:
        integration_prompt += "\n표가 발견되지 않았습니다."

    integration_prompt += "\n\n=== 이미지 분석 결과 ===\n"

    if image_analyses:
        for image_name, analysis in image_analyses.items():
            integration_prompt += f"\n{image_name}: {analysis['analysis'][:300]}..."
    else:
        integration_prompt += "\n이미지가 발견되지 않았습니다."

    integration_prompt += f"""

    === 통합 분석 요청사항 ===
    1. 전체 문서의 주요 주제와 목적
    2. 텍스트, 표, 이미지 간의 관계와 상호작용
    3. 주요 인사이트와 결론
    4. {content_type['type']} 유형 문서로서의 특징
    5. 추가 분석이나 활용 방안 제안
    """

    try:
        key = api_key or os.getenv('GOOGLE_API_KEY')
        if not key:
            raise ValueError("Google API 키가 필요합니다.")
        genai.configure(api_key=key)
        model = genai.GenerativeModel('gemini-2.5-pro')

        response = model.generate_content(
            integration_prompt,
            generation_config=genai.types.GenerationConfig(max_output_tokens=2000)
        )

        return {
            "integrated_analysis": response.text,
            "content_type": content_type,
            "components": {
                "text_length": len(text_content),
                "table_count": len(table_analyses) if table_analyses else 0,
                "image_count": len(image_analyses) if image_analyses else 0
            }
        }

    except Exception as e:
        print(f"통합 분석 실패: {e}")
        return None


def analyze_pdf_comprehensive(pdf_path, output_dir="./data/analysis/", api_key=None):
    """PDF를 텍스트, 표, 이미지 모두 분석하는 종합 함수."""
    os.makedirs(output_dir, exist_ok=True)

    print("=== 멀티모달 PDF 분석 시작 ===")
    print(f"대상 파일: {pdf_path}")

    results = {
        "pdf_path": pdf_path,
        "text_analysis": None,
        "table_analysis": None,
        "image_analysis": None,
        "integrated_analysis": None
    }

    # 1. 텍스트 추출
    print("1. 텍스트 콘텐츠 추출 중...")
    try:
        text_content = extract_text_from_pdf(pdf_path)
        results["text_analysis"] = {
            "content": text_content,
            "length": len(text_content),
            "pages": len(text_content.split("=== 페이지"))
        }
        print(f"   텍스트 추출 완료: {len(text_content)}자")
    except Exception as e:
        print(f"   텍스트 추출 실패: {e}")

    # 2. 표 추출 및 분석
    print("2. 표 데이터 추출 및 분석 중...")
    try:
        table_results = analyze_pdf_tables_with_gemini(
            pdf_path,
            output_dir=os.path.join(output_dir, "tables/"),
            api_key=api_key
        )
        if table_results:
            results["table_analysis"] = table_results
            print(f"   표 분석 완료: {table_results['total_tables']}개")
        else:
            print("   표가 발견되지 않았습니다.")
    except Exception as e:
        print(f"   표 분석 실패: {e}")

    # 3. 이미지 추출 및 분석
    print("3. 이미지 추출 및 분석 중...")
    try:
        image_results = analyze_pdf_images_with_gemini(
            pdf_path,
            output_dir=os.path.join(output_dir, "images/"),
            api_key=api_key
        )
        if image_results:
            results["image_analysis"] = image_results
            print(f"   이미지 분석 완료: {image_results['total_images']}개")
        else:
            print("   이미지가 발견되지 않았습니다.")
    except Exception as e:
        print(f"   이미지 분석 실패: {e}")

    # 4. 통합 분석
    print("4. 멀티모달 콘텐츠 통합 분석 중...")
    if results["text_analysis"] and (results["table_analysis"] or results["image_analysis"]):
        text_content = results["text_analysis"]["content"]
        table_analyses = results["table_analysis"]["individual_analyses"] if results["table_analysis"] else {}
        image_analyses = results["image_analysis"]["individual_analyses"] if results["image_analysis"] else {}

        integrated = generate_integrated_analysis(text_content, table_analyses, image_analyses, api_key=api_key)
        if integrated:
            results["integrated_analysis"] = integrated
            print("   통합 분석 완료")
        else:
            print("   통합 분석 실패")
    else:
        print("   통합 분석을 위한 충분한 데이터가 없습니다.")

    return results


def generate_analysis_report(analysis_results, output_file="./data/multimodal_report.md"):
    """멀티모달 분석 결과를 종합 보고서로 저장합니다."""
    if not analysis_results:
        print("보고서 생성에 필요한 데이터가 없습니다.")
        return

    report_content = f"""# PDF 멀티모달 분석 보고서

## 분석 개요
- **파일 경로**: {analysis_results['pdf_path']}
- **분석 일시**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""

    if analysis_results.get('text_analysis'):
        text_info = analysis_results['text_analysis']
        report_content += f"""
## 텍스트 분석 결과
- **텍스트 길이**: {text_info['length']}자
- **페이지 수**: {text_info['pages']}페이지
- **콘텐츠 유형**: {analysis_results.get('integrated_analysis', {}).get('content_type', {}).get('type', 'unknown')}

### 텍스트 콘텐츠 (발췌)
```
{text_info['content'][:500]}...
```
"""

    if analysis_results.get('table_analysis'):
        table_info = analysis_results['table_analysis']
        report_content += f"""
## 표 분석 결과
- **총 표 개수**: {table_info['total_tables']}

### 표별 분석
"""
        for table_name, analysis in table_info['individual_analyses'].items():
            report_content += f"""
#### {table_name}
- **크기**: {analysis['row_count']}행 × {analysis['column_count']}열
- **분석 결과**: {analysis['analysis'][:300]}...
"""
        if table_info.get('summary'):
            report_content += f"""
### 표 종합 요약
{table_info['summary']}
"""

    if analysis_results.get('image_analysis'):
        image_info = analysis_results['image_analysis']
        report_content += f"""
## 이미지 분석 결과
- **총 이미지 개수**: {image_info['total_images']}

### 이미지별 분석
"""
        for image_name, analysis in image_info['individual_analyses'].items():
            report_content += f"""
#### {image_name}
{analysis['analysis']}
"""
        if image_info.get('summary'):
            report_content += f"""
### 이미지 종합 요약
{image_info['summary']}
"""

    if analysis_results.get('integrated_analysis'):
        integrated = analysis_results['integrated_analysis']
        components = integrated['components']
        report_content += f"""
## 통합 멀티모달 분석
- **콘텐츠 유형**: {integrated['content_type']['type']} (신뢰도: {integrated['content_type']['confidence']:.2f})
- **분석 구성 요소**: 텍스트({components['text_length']}자), 표({components['table_count']}개), 이미지({components['image_count']}개)

### 통합 분석 결과
{integrated['integrated_analysis']}
"""

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(report_content)

    print(f"멀티모달 분석 보고서가 {output_file}에 저장되었습니다.")


if __name__ == "__main__":
    import warnings, logging
    warnings.filterwarnings('ignore')
    logging.disable(logging.CRITICAL)
    if sys.platform == 'win32':
        os.system('chcp 65001 > nul')
    sys.stdout.reconfigure(encoding='utf-8')
    from pathlib import Path
    from dotenv import load_dotenv

    script_dir = Path(__file__).resolve().parent
    _env_path = script_dir.parent / ".env"
    if not _env_path.exists():
        print(f"[ERROR] .env 파일을 찾을 수 없습니다: {_env_path}")
        sys.exit(1)
    load_dotenv(_env_path, override=True)

    pdf_path = "../data/sample.pdf"
    print("=== 멀티모달 PDF 분석 시작 ===")

    results = analyze_pdf_comprehensive(pdf_path)

    if results:
        print("\n=== 분석 완료 ===")
        if results.get('text_analysis'):
            print(f"텍스트: {results['text_analysis']['length']}자, {results['text_analysis']['pages']}페이지")
        if results.get('table_analysis'):
            print(f"표: {results['table_analysis']['total_tables']}개")
        if results.get('image_analysis'):
            print(f"이미지: {results['image_analysis']['total_images']}개")
        if results.get('integrated_analysis'):
            ct = results['integrated_analysis']['content_type']
            print(f"콘텐츠 유형: {ct['type']} (신뢰도: {ct['confidence']:.2f})")

        generate_analysis_report(results)
        print("\n분석이 완료되었습니다! 결과: ./data/analysis/")

    else:
        print("분석에 실패했습니다. .env 파일의 GOOGLE_API_KEY를 확인해주세요.")
