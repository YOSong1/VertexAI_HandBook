from PIL import Image
import os, types, sys

# 테스트 환경: google.generativeai가 없을 수 있으므로 최소한의 fake 모듈 제공
fake_types = types.SimpleNamespace()
fake_types.GenerationConfig = lambda **kwargs: kwargs

class _FinishReason:
    MAX_TOKENS = 2
    STOP = 1

fake_protos = types.SimpleNamespace(Candidate=types.SimpleNamespace(FinishReason=_FinishReason))

fake_genai_mod = types.ModuleType('google.generativeai')
fake_genai_mod.types = fake_types
fake_genai_mod.protos = fake_protos
fake_genai_mod.configure = lambda api_key=None: None

# 모듈을 sys.modules에 주입
import importlib
import types as _types
sys.modules['google'] = _types.ModuleType('google')
sys.modules['google.generativeai'] = fake_genai_mod

# 경로에 모듈이 있는 폴더 추가
sys.path.insert(0, os.path.abspath('02_pdf'))
from pdf_gemini_vision import analyze_image

# 준비: 임시 이미지 생성
os.makedirs('data/tem', exist_ok=True)
img_path = os.path.abspath('data/tem/test_image.png')
im = Image.new('RGB', (10,10), color=(255,0,0))
im.save(img_path)

class FakeResponse:
    def __init__(self, text_value=None, raise_text=False, candidates=None):
        self._text_value = text_value
        self._raise_text = raise_text
        self.candidates = candidates or []
    @property
    def text(self):
        if self._raise_text:
            raise ValueError('simulated missing parts')
        return self._text_value

class FakeModel:
    def __init__(self):
        self.call = 0
    def generate_content(self, contents, generation_config=None, stream=False, **kwargs):
        self.call += 1
        if not stream:
            if self.call == 1:
                cand = types.SimpleNamespace(finish_reason=fake_protos.Candidate.FinishReason.MAX_TOKENS, content=types.SimpleNamespace(parts=[]))
                return FakeResponse(text_value=None, raise_text=True, candidates=[cand])
            else:
                part = types.SimpleNamespace(text='모의 분석 결과 텍스트')
                cand = types.SimpleNamespace(finish_reason=fake_protos.Candidate.FinishReason.STOP, content=types.SimpleNamespace(parts=[part]))
                return FakeResponse(text_value='모의 분석 결과 텍스트', raise_text=False, candidates=[cand])
        else:
            def gen():
                chunk = types.SimpleNamespace(text='streamed chunk', candidates=[])
                yield chunk
            return gen()

if __name__ == '__main__':
    fm = FakeModel()
    res = analyze_image(img_path, custom_prompt='테스트 프롬프트', max_tokens=1, model=fm)
    print('analyze_image 반환:', repr(res))
