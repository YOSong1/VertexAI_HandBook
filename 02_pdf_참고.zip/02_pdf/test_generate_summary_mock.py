import sys, os, types
# inject minimal fake google.generativeai if not present
fake_types = types.SimpleNamespace()
fake_types.GenerationConfig = lambda **kwargs: kwargs

class _FinishReason:
    MAX_TOKENS = 2
    STOP = 1

fake_protos = types.SimpleNamespace(Candidate=types.SimpleNamespace(FinishReason=_FinishReason))

fake_genai_mod = types.ModuleType('google.generativeai')
fake_genai_mod.types = fake_types
fake_genai_mod.protos = fake_protos
fake_genai_mod.configure = lambda api_key=None: None

import types as _types
sys.modules['google'] = _types.ModuleType('google')
sys.modules['google.generativeai'] = fake_genai_mod

sys.path.insert(0, os.path.abspath('02_pdf'))
from pdf_gemini_vision import generate_image_summary

# small fake analysis_results
analysis_results = {
    'page_1_image_1.png': {'analysis': '이미지1 분석 요약 텍스트'},
    'page_2_image_1.png': {'analysis': '이미지2 분석 요약 텍스트'},
}

class FakeResponse:
    def __init__(self, text):
        self._text = text
    @property
    def text(self):
        return self._text

class FakeModel:
    def generate_content(self, contents, generation_config=None, stream=False, **kwargs):
        return FakeResponse('모의 종합 요약 결과')

if __name__ == '__main__':
    fm = FakeModel()
    summary = generate_image_summary(analysis_results, model=fm, max_tokens=2048)
    print('generate_image_summary 반환:')
    print(summary)
