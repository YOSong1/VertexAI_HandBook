"""
PDF에서 추출된 이미지를 Gemini Vision으로 분석하는 모듈
"""
import os
import sys
from PIL import Image
import google.generativeai as genai

from pdf_extract import extract_images_from_pdf


def get_gemini_model(api_key=None, model_name='gemini-2.5-pro'):
    key = api_key or os.getenv('GOOGLE_API_KEY')
    if not key:
        raise ValueError("Google API 키가 필요합니다. .env 파일에 GOOGLE_API_KEY를 설정하세요.")
    genai.configure(api_key=key)
    return genai.GenerativeModel(model_name)


def analyze_image(image_path, custom_prompt=None, max_tokens=2048, api_key=None, model=None):
    """단일 이미지를 Gemini Vision으로 분석합니다."""
    if custom_prompt is None:
        custom_prompt = """
        이 이미지를 자세히 분석해주세요:

        1. 이미지의 주요 콘텐츠와 주제
        2. 이미지의 유형 (차트, 다이어그램, 사진, 일러스트 등)
        3. 포함된 텍스트나 레이블
        4. 이미지의 목적이나 기능
        5. 주요 인사이트나 특징

        가능한 한 구체적이고 유용한 정보를 제공해주세요.
        """

    try:
        _model = model or get_gemini_model(api_key)
        img = Image.open(image_path)

        # 진단 정보 (프롬프트 길이, 이미지 파일 크기 등)
        try:
            img_size = os.path.getsize(image_path)
        except Exception:
            img_size = None
        print(f"요청 준비: prompt_len={len(custom_prompt) if custom_prompt else 0}, image_size={img_size}, max_tokens={max_tokens}")

        attempt = 0
        max_retries = 3
        current_max = max_tokens
        max_cap = 16384

        while True:
            response = _model.generate_content(
                [custom_prompt, img],
                generation_config=genai.types.GenerationConfig(max_output_tokens=current_max)
            )

            # 안전하게 텍스트를 얻어보기
            try:
                return response.text
            except ValueError as ve:
                print(f"response.text 접근 실패: {ve}")
                # 후보 상태 확인
                try:
                    candidates = response.candidates
                except Exception:
                    candidates = None

                if candidates and len(candidates) > 0:
                    cand = candidates[0]
                    fr = cand.finish_reason
                    FinishReason = genai.protos.Candidate.FinishReason
                    if fr == FinishReason.MAX_TOKENS and attempt < max_retries:
                        attempt += 1
                        current_max = min(current_max * 2, max_cap)
                        print(f"MAX_TOKENS 도달: 재시도 {attempt}/{max_retries} with max_output_tokens={current_max}")
                        continue

                # 스트리밍 폴백 시도
                try:
                    print("스트리밍 폴백 시도...")
                    stream_resp = _model.generate_content(
                        [custom_prompt, img],
                        generation_config=genai.types.GenerationConfig(max_output_tokens=current_max),
                        stream=True,
                    )
                    collected = []
                    for chunk in stream_resp:
                        try:
                            collected.append(chunk.text)
                        except Exception:
                            # 후보의 parts에서 수동 추출
                            try:
                                cand_list = chunk.candidates
                                if cand_list:
                                    parts = cand_list[0].content.parts
                                    texts = []
                                    for part in parts:
                                        if hasattr(part, 'text') and part.text:
                                            texts.append(part.text)
                                    if texts:
                                        collected.append("\n".join(texts))
                            except Exception:
                                pass

                    if collected:
                        return "\n".join([c for c in collected if c])
                except Exception as e_stream:
                    print(f"스트리밍 폴백 실패: {e_stream}")

                return None

    except Exception as e:
        print(f"이미지 분석 실패: {e}")
        return None


def analyze_images_batch(image_paths, analysis_type="general", api_key=None, model=None, max_tokens=2048):
    """여러 이미지를 배치로 분석합니다."""
    results = {}

    prompts = {
        "general": "이 이미지를 자세히 분석해주세요. 콘텐츠, 유형, 목적을 설명하세요.",
        "chart": """
        이 차트/그래프를 분석해주세요:
        1. 차트 유형 (막대, 선, 원형 등)
        2. 주요 데이터 포인트와 추세
        3. 차트의 목적과 결론
        4. 주목할 만한 인사이트
        """,
        "diagram": """
        이 다이어그램을 분석해주세요:
        1. 다이어그램의 유형과 목적
        2. 주요 구성 요소와 관계
        3. 프로세스나 시스템의 흐름
        4. 중요한 개념이나 단계
        """,
        "photo": """
        이 사진을 분석해주세요:
        1. 사진의 주제와 콘텐츠
        2. 시각적 요소와 구성
        3. 사진의 맥락이나 목적
        4. 특이사항이나 특징
        """
    }

    prompt = prompts.get(analysis_type, prompts["general"])
    _model = model or get_gemini_model(api_key)

    for i, image_path in enumerate(image_paths):
        print(f"이미지 {i+1}/{len(image_paths)} 분석 중: {os.path.basename(image_path)}")
        analysis = analyze_image(image_path, custom_prompt=prompt, model=_model, max_tokens=max_tokens)
        if analysis:
            results[os.path.basename(image_path)] = {
                "path": image_path,
                "analysis": analysis,
                "type": analysis_type
            }
        else:
            # 실패한 항목도 기록하여 이후 요약/디버깅에 사용
            results[os.path.basename(image_path)] = {
                "path": image_path,
                "analysis": "",
                "error": "analysis_failed",
                "type": analysis_type
            }

    return results


def generate_image_summary(analysis_results, api_key=None, model=None, max_tokens=2048):
    """여러 이미지 분석 결과를 종합하여 요약합니다.

    향후 실패를 대비해 재시도와 스트리밍 폴백을 지원합니다.
    """
    if not analysis_results:
        return "분석할 이미지가 없습니다."

    combined_analysis = ""
    for image_name, result in analysis_results.items():
        combined_analysis += f"\n=== {image_name} ===\n"
        combined_analysis += result.get("analysis", "") + "\n"

    summary_prompt = f"""
    다음은 여러 이미지의 분석 결과입니다. 이를 종합하여 요약해주세요:

    {combined_analysis}

    요약 내용:
    1. 전체 이미지들의 공통 주제나 목적
    2. 주요 패턴이나 특징
    3. 종합적인 인사이트
    4. 추가 권장사항이나 결론
    """

    print(f"요약 요청: images={len(analysis_results)}, prompt_len={len(summary_prompt)} chars, max_tokens={max_tokens}")

    try:
        _model = model or get_gemini_model(api_key)
    except Exception as e:
        print(f"요약용 모델 준비 실패: {e}")
        return "요약 생성에 실패했습니다."

    attempt = 0
    max_retries = 3
    current_max = max_tokens
    max_cap = 16384

    while True:
        try:
            response = _model.generate_content(
                summary_prompt,
                generation_config=genai.types.GenerationConfig(max_output_tokens=current_max),
            )

            try:
                return response.text
            except ValueError as ve:
                print(f"요약 response.text 접근 실패: {ve}")
                # 후보 확인
                try:
                    candidates = response.candidates
                except Exception:
                    candidates = None

                if candidates and len(candidates) > 0:
                    cand = candidates[0]
                    fr = cand.finish_reason
                    FinishReason = genai.protos.Candidate.FinishReason
                    if fr == FinishReason.MAX_TOKENS and attempt < max_retries:
                        attempt += 1
                        current_max = min(current_max * 2, max_cap)
                        print(f"요약 MAX_TOKENS 도달: 재시도 {attempt}/{max_retries} with max_output_tokens={current_max}")
                        continue

                # 스트리밍 폴백 시도
                try:
                    print("요약 스트리밍 폴백 시도...")
                    stream_resp = _model.generate_content(
                        summary_prompt,
                        generation_config=genai.types.GenerationConfig(max_output_tokens=current_max),
                        stream=True,
                    )
                    collected = []
                    for chunk in stream_resp:
                        try:
                            collected.append(chunk.text)
                        except Exception:
                            try:
                                cand_list = chunk.candidates
                                if cand_list:
                                    parts = cand_list[0].content.parts
                                    texts = []
                                    for part in parts:
                                        if hasattr(part, 'text') and part.text:
                                            texts.append(part.text)
                                    if texts:
                                        collected.append("\n".join(texts))
                            except Exception:
                                pass

                    if collected:
                        return "\n".join([c for c in collected if c])
                except Exception as e_stream:
                    print(f"요약 스트리밍 폴백 실패: {e_stream}")

                return "요약 생성에 실패했습니다."

        except Exception as e:
            # 페이로드 초과 메시지 처리
            msg = str(e)
            if "Request payload size exceeds the limit" in msg and attempt < max_retries:
                attempt += 1
                # 단순한 폴백: combined_analysis를 잘라 재시도
                keep_chars = 12000
                if len(combined_analysis) > keep_chars:
                    combined_analysis = combined_analysis[-keep_chars:]
                    summary_prompt = f"""
    다음은 여러 이미지의 분석 결과입니다. 이를 종합하여 요약해주세요:

    {combined_analysis}

    요약 내용:
    1. 전체 이미지들의 공통 주제나 목적
    2. 주요 패턴이나 특징
    3. 종합적인 인사이트
    4. 추가 권장사항이나 결론
    """
                    print(f"페이로드 초과로 프롬프트 축소 후 재시도 {attempt}/{max_retries} (prompt_len={len(summary_prompt)})")
                    continue
            print(f"요약 생성 실패: {e}")
            return "요약 생성에 실패했습니다."


def analyze_pdf_images_with_gemini(pdf_path, output_dir="./data/images/", analysis_type="general", api_key=None, max_tokens=2048):
    """PDF에서 이미지를 추출하고 Gemini Vision으로 분석하는 통합 함수."""
    print("PDF에서 이미지 추출 중...")
    extract_images_from_pdf(pdf_path, output_dir)

    image_files = [
        os.path.join(output_dir, f)
        for f in os.listdir(output_dir)
        if f.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp'))
    ]

    if not image_files:
        print("추출된 이미지가 없습니다.")
        return None

    print(f"총 {len(image_files)}개의 이미지 발견")

    try:
        _model = get_gemini_model(api_key)

        print("Gemini Vision으로 이미지 분석 중...")
        results = analyze_images_batch(image_files, analysis_type, model=_model, max_tokens=max_tokens)

        if results:
            print("종합 요약 생성 중...")
            summary = generate_image_summary(results, model=_model, max_tokens=max_tokens)
            return {
                "individual_analyses": results,
                "summary": summary,
                "total_images": len(image_files)
            }

    except Exception as e:
        print(f"Gemini Vision 분석 실패: {e}")
        return None


if __name__ == "__main__":
    import warnings, logging
    warnings.filterwarnings('ignore')
    logging.disable(logging.CRITICAL)
    if sys.platform == 'win32':
        os.system('chcp 65001 > nul')
    sys.stdout.reconfigure(encoding='utf-8')
    from pathlib import Path
    from dotenv import load_dotenv

    script_dir = Path(__file__).resolve().parent
    _env_path = script_dir.parent / ".env"
    if not _env_path.exists():
        print(f"[ERROR] .env 파일을 찾을 수 없습니다: {_env_path}")
        sys.exit(1)
    load_dotenv(_env_path, override=True)

    pdf_path = "../data/sample.pdf"
    print("=== PDF 이미지 Gemini Vision 분석 시작 ===")

    results = analyze_pdf_images_with_gemini(pdf_path, analysis_type="general")

    if results:
        print(f"\n총 {results['total_images']}개의 이미지 분석 완료")

        print("\n=== 개별 이미지 분석 결과 ===")
        for image_name, analysis in results['individual_analyses'].items():
            text = analysis['analysis']
            print(f"\n{image_name}:")
            print(text[:200] + "..." if len(text) > 200 else text)

        print("\n=== 종합 요약 ===")
        print(results['summary'])

    else:
        print("분석에 실패했습니다. .env 파일의 GOOGLE_API_KEY를 확인해주세요.")
