"""
PDF 기본 추출 함수 모음 — 텍스트, 이미지, 표 추출
"""
import io
import os
import sys

import pdfplumber
from PIL import Image, UnidentifiedImageError
from PyPDF2 import PdfReader
import tabula
import pandas as pd


def extract_text_from_pdf(pdf_path):
    """PDF 파일에서 텍스트를 추출합니다 (페이지별 구분)."""
    try:
        reader = PdfReader(pdf_path)
        text = ""
        for i, page in enumerate(reader.pages):
            page_text = page.extract_text()
            if page_text:
                text += f"=== 페이지 {i+1} ===\n{page_text}\n\n"
        return text
    except Exception as e:
        print(f"PDF 처리 중 오류 발생: {str(e)}")
        return f"오류 발생: {str(e)}"


def analyze_pdf_structure(pdf_path):
    """PDF 구조(메타데이터, 페이지 정보)를 출력합니다."""
    try:
        reader = PdfReader(pdf_path)
        print(f"PDF 파일: {pdf_path}")
        print(f"페이지 수: {len(reader.pages)}")

        print("\nPDF 메타데이터:")
        metadata = reader.metadata
        if metadata:
            for key, value in metadata.items():
                if value:
                    print(f"  {key}: {value}")
        else:
            print("  메타데이터 없음")

        print("\n페이지 정보:")
        for i, page in enumerate(reader.pages):
            print(f"  페이지 {i+1}:")
            print(f"    크기: {page.mediabox}")
            print(f"    텍스트 길이: {len(page.extract_text())}")

    except Exception as e:
        print(f"PDF 분석 중 오류 발생: {str(e)}")


def extract_images_from_pdf(pdf_path, output_dir="./data/images/"):
    """PDF 파일에서 이미지를 추출하여 저장합니다."""
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    with pdfplumber.open(pdf_path) as pdf:
        image_count = 0
        skipped_count = 0

        for page_num, page in enumerate(pdf.pages):
            print(f"페이지 {page_num+1} 처리 중...")
            try:
                for image_idx, image_obj in enumerate(page.images):
                    try:
                        image_data = image_obj['stream'].get_data()
                        try:
                            image = Image.open(io.BytesIO(image_data))
                            image_path = f"{output_dir}page_{page_num+1}_image_{image_count+1}.png"
                            image.save(image_path)
                            print(f"이미지 {image_count+1}이 {image_path}에 저장되었습니다.")
                            image_count += 1
                        except UnidentifiedImageError:
                            print(f"페이지 {page_num+1}의 이미지 {image_idx+1}을 인식할 수 없습니다. 건너뜁니다.")
                            skipped_count += 1
                        except Exception as e:
                            print(f"페이지 {page_num+1}의 이미지 {image_idx+1} 처리 중 오류 발생: {str(e)}")
                            skipped_count += 1
                    except Exception as e:
                        print(f"이미지 객체 처리 중 오류 발생: {str(e)}")
                        skipped_count += 1
            except Exception as e:
                print(f"페이지 {page_num+1} 처리 중 오류 발생: {str(e)}")

        if image_count == 0:
            print("PDF에서 추출된 이미지가 없습니다.")
        else:
            print(f"총 {image_count}개의 이미지가 추출되었습니다.")

        if skipped_count > 0:
            print(f"{skipped_count}개의 이미지를 건너뛰었습니다.")


def extract_tables_from_pdf(pdf_path, pages="all", encoding='CP949'):
    """PDF 파일에서 표 데이터를 추출합니다."""
    dfs = tabula.read_pdf(pdf_path, pages=pages, encoding=encoding)
    return dfs


def save_tables_to_csv(dfs, output_dir="./data/"):
    """추출된 표 데이터를 CSV 파일로 저장합니다."""
    for i, df in enumerate(dfs):
        output_path = f"{output_dir}table_{i+1}.csv"
        df.to_csv(output_path, index=False, encoding='CP949')
        print(f"표 {i+1}이 {output_path}에 저장되었습니다.")


if __name__ == "__main__":
    import warnings, logging
    warnings.filterwarnings('ignore')
    logging.disable(logging.CRITICAL)
    if sys.platform == 'win32':
        os.system('chcp 65001 > nul')
    sys.stdout.reconfigure(encoding='utf-8')
    from pathlib import Path
    from dotenv import load_dotenv

    script_dir = Path(__file__).resolve().parent
    _env_path = script_dir.parent / ".env"
    if not _env_path.exists():
        print(f"[ERROR] .env 파일을 찾을 수 없습니다: {_env_path}")
        sys.exit(1)
    load_dotenv(_env_path, override=True)

    pdf_path = input("PDF 파일 경로를 입력하세요: ").strip()
    if not pdf_path:
        print("PDF 파일 경로를 입력하지 않았습니다.")
        sys.exit(1)

    pdf_path = os.path.abspath(pdf_path)

    print("\nPDF 구조 분석 결과:")
    analyze_pdf_structure(pdf_path)

    print("\nPDF 텍스트 추출 결과:")
    print(extract_text_from_pdf(pdf_path))

    print("\n이미지 추출 결과:")
    extract_images_from_pdf(pdf_path)

    print("\n표 추출 결과:")
    dfs = extract_tables_from_pdf(pdf_path)
    print(f"추출된 테이블 수: {len(dfs)}")
    for i, df in enumerate(dfs):
        print(f"\n테이블 {i+1}:")
        print(df)
    save_tables_to_csv(dfs)
