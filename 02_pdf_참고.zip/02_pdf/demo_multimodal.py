"""
멀티모달 PDF 분석 데모 스크립트
"""
import os
import sys
import warnings
import logging
warnings.filterwarnings('ignore')
logging.disable(logging.CRITICAL)
if sys.platform == 'win32':
    os.system('chcp 65001 > nul')
sys.stdout.reconfigure(encoding='utf-8')
from pathlib import Path
from dotenv import load_dotenv

# .env 로드: 프로젝트 루트(스크립트의 상위 폴더)에서 .env를 로드합니다.
# override=True: 시스템 환경변수를 무시하고 .env 값을 우선 사용합니다.
script_dir = Path(__file__).resolve().parent
_env_path = script_dir.parent / ".env"
if not _env_path.exists():
    print(f"[ERROR] .env 파일을 찾을 수 없습니다: {_env_path}")
    sys.exit(1)
load_dotenv(_env_path, override=True)

from pdf_multimodal_analyzer import analyze_pdf_comprehensive, generate_analysis_report


def setup_environment():
    """환경 설정 및 API 키 확인"""
    print("환경 설정 확인 중...")

    api_key = os.getenv('GOOGLE_API_KEY')
    if not api_key:
        print("Google API 키가 설정되지 않았습니다.")
        print("   .env 파일에 다음과 같이 설정하세요:")
        print("   GOOGLE_API_KEY=your-key-here")
        return False

    masked_key = api_key[:8] + "..." + api_key[-4:] if len(api_key) > 12 else api_key
    print(f"Google API 키 확인됨: {masked_key}")

    os.makedirs("./data/analysis", exist_ok=True)
    os.makedirs("./data/analysis/tables", exist_ok=True)
    os.makedirs("./data/analysis/images", exist_ok=True)
    print("분석 디렉토리 생성됨")

    return True


def main():
    pdf_path = "../data/sample.pdf"

    if not os.path.exists(pdf_path):
        print(f"PDF 파일을 찾을 수 없습니다: {pdf_path}")
        data_dir = "../data/"
        if os.path.exists(data_dir):
            print("사용 가능한 PDF 파일들:")
            for file in os.listdir(data_dir):
                if file.endswith('.pdf'):
                    print(f"  - {file}")
        return

    print("멀티모달 PDF 분석 데모 시작")
    print(f"대상 파일: {pdf_path}")
    print("=" * 50)

    try:
        print("PDF 분석 중...")
        results = analyze_pdf_comprehensive(pdf_path)

        if results:
            print("분석 완료!")
            print("=" * 50)
            print("분석 결과 요약:")
            print("-" * 30)

            if results.get('text_analysis'):
                text_info = results['text_analysis']
                print(f"텍스트 콘텐츠: {text_info['length']:,}자, {text_info['pages']}페이지")
                print(f"   └─ 샘플: {text_info['content'][:100]}...")

            if results.get('table_analysis'):
                table_info = results['table_analysis']
                print(f"표 데이터: {table_info['total_tables']}개 표 발견")
                if table_info['individual_analyses']:
                    first_table = list(table_info['individual_analyses'].keys())[0]
                    analysis = table_info['individual_analyses'][first_table]
                    print(f"   └─ 첫 번째 표: {analysis['row_count']}행 × {analysis['column_count']}열")

            if results.get('image_analysis'):
                image_info = results['image_analysis']
                print(f"이미지: {image_info['total_images']}개 이미지 발견")
                if image_info['individual_analyses']:
                    first_image = list(image_info['individual_analyses'].keys())[0]
                    print(f"   └─ 첫 번째 이미지: {first_image}")

            if results.get('integrated_analysis'):
                integrated = results['integrated_analysis']
                content_type = integrated['content_type']
                components = integrated['components']
                print(f"콘텐츠 유형: {content_type['type']} (신뢰도: {content_type['confidence']:.1%})")
                print(f"구성 요소: 텍스트({components['text_length']:,}자), 표({components['table_count']}개), 이미지({components['image_count']}개)")

                print("\n주요 인사이트:")
                insights = integrated['integrated_analysis'][:300] + "..."
                print(f"   {insights}")

            print("\n상세 보고서 생성 중...")
            generate_analysis_report(results)
            print("보고서 생성 완료: ./data/multimodal_report.md")

            print("\n분석 파일들:")
            print("   ./data/analysis/")
            print("      ├── tables/     (추출된 표 CSV 파일들)")
            print("      ├── images/     (추출된 이미지 파일들)")
            print("      └── multimodal_report.md (종합 분석 보고서)")

        else:
            print("분석에 실패했습니다.")
            print("가능한 원인:")
            print("   - Google API 키가 설정되지 않음")
            print("   - PDF 파일이 손상됨")
            print("   - 네트워크 연결 문제")

    except Exception as e:
        print(f"오류 발생: {e}")
        print("문제 해결:")
        print("   1. .env 파일에 GOOGLE_API_KEY 설정")
        print("   2. pip install -r requirements.txt 실행")
        print("   3. PDF 파일 경로 확인")


if __name__ == "__main__":
    print("PDF 멀티모달 분석 시스템")
    print("=" * 50)

    if setup_environment():
        main()
    else:
        print("\n환경 설정이 완료되지 않았습니다.")
        print("   위의 지침에 따라 API 키를 설정한 후 다시 실행해주세요.")

    print("\n" + "=" * 50)
    print("데모 종료")
