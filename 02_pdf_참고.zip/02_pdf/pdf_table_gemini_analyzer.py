"""
PDF에서 추출된 표 데이터를 Gemini로 분석하는 모듈
"""
import os
import sys
import pandas as pd
import google.generativeai as genai

from pdf_extract import extract_tables_from_pdf, save_tables_to_csv


def get_gemini_model(api_key=None, model_name='gemini-2.5-pro'):
    key = api_key or os.getenv('GOOGLE_API_KEY')
    if not key:
        raise ValueError("Google API 키가 필요합니다. .env 파일에 GOOGLE_API_KEY를 설정하세요.")
    genai.configure(api_key=key)
    return genai.GenerativeModel(model_name)


def _safe_response_text(response, fallback="응답을 가져올 수 없습니다."):
    """Gemini 응답에서 안전하게 텍스트를 추출합니다."""
    try:
        if not response.candidates:
            return fallback + " (빈 candidates)"
        candidate = response.candidates[0]
        finish_name = candidate.finish_reason.name if hasattr(candidate.finish_reason, 'name') else str(candidate.finish_reason)
        if finish_name not in ("STOP", "MAX_TOKENS", "1", "2"):
            return f"{fallback} (차단됨: {finish_name})"
        return response.text
    except (ValueError, AttributeError, IndexError) as e:
        return f"{fallback} ({e})"


def analyze_table(df, table_name="표", custom_prompt=None, max_tokens=2048, api_key=None, model=None):
    """단일 표 데이터를 Gemini로 분석합니다."""
    if df.empty:
        return f"{table_name}: 빈 표입니다."

    table_text = df.to_string(index=True)

    if custom_prompt is None:
        custom_prompt = f"""
        다음 표 데이터를 분석해주세요:

        {table_text}

        분석 내용:
        1. 표의 주요 목적과 주제
        2. 데이터 구조와 특징
        3. 주요 패턴이나 추세
        4. 중요한 인사이트나 결론
        5. 추가 분석 제안사항

        표의 내용을 기반으로 유용한 정보를 추출해주세요.
        """

    try:
        _model = model or get_gemini_model(api_key)
        response = _model.generate_content(
            custom_prompt,
            generation_config=genai.types.GenerationConfig(max_output_tokens=max_tokens)
        )
        result = _safe_response_text(response, f"{table_name}: 분석 실패")
        return result

    except Exception as e:
        print(f"표 분석 실패: {e}")
        return f"{table_name}: 분석 실패 - {str(e)}"


def analyze_tables_batch(dfs, analysis_type="general", api_key=None, model=None):
    """여러 표를 배치로 분석합니다."""
    results = {}

    prompts = {
        "general": "이 표를 분석해주세요. 구조, 내용, 인사이트를 설명하세요.",
        "financial": """
        이 재무 표를 분석해주세요:
        1. 주요 재무 지표와 추세
        2. 재무 상태 평가
        3. 잠재적 위험 요소
        4. 개선 방안 제안
        """,
        "statistical": """
        이 통계 데이터를 분석해주세요:
        1. 데이터 분포와 특징
        2. 주요 통계적 인사이트
        3. 추세 분석
        4. 시각화 제안
        """,
        "comparison": """
        이 비교 표를 분석해주세요:
        1. 비교 대상과 기준
        2. 주요 차이점과 유사점
        3. 추천사항이나 결론
        4. 추가 고려사항
        """
    }

    prompt_template = prompts.get(analysis_type, prompts["general"])
    _model = model or get_gemini_model(api_key)

    for i, df in enumerate(dfs):
        table_name = f"표_{i+1}"
        print(f"{table_name} 분석 중...")

        custom_prompt = f"""
        다음은 {table_name}입니다:

        {df.to_string(index=True)}

        {prompt_template}
        """

        analysis = analyze_table(df, table_name, custom_prompt, model=_model)
        if analysis:
            results[table_name] = {
                "dataframe": df,
                "analysis": analysis,
                "row_count": len(df),
                "column_count": len(df.columns),
                "type": analysis_type
            }

    return results


def generate_tables_summary(analysis_results, api_key=None, model=None):
    """여러 표 분석 결과를 종합하여 요약합니다."""
    if not analysis_results:
        return "분석할 표가 없습니다."

    combined_analysis = ""
    for table_name, result in analysis_results.items():
        combined_analysis += f"\n=== {table_name} ===\n"
        combined_analysis += f"크기: {result['row_count']}행 x {result['column_count']}열\n"
        combined_analysis += result["analysis"] + "\n"

    summary_prompt = f"""
    다음은 여러 표의 분석 결과입니다. 이를 종합하여 요약해주세요:

    {combined_analysis}

    종합 요약:
    1. 전체 표들의 공통 주제나 목적
    2. 데이터 간의 관계와 패턴
    3. 주요 종합 인사이트
    4. 추가 분석이나 활용 방안
    """

    try:
        _model = model or get_gemini_model(api_key)
        response = _model.generate_content(
            summary_prompt,
            generation_config=genai.types.GenerationConfig(max_output_tokens=3000)
        )
        return _safe_response_text(response, "요약 생성에 실패했습니다.")

    except Exception as e:
        print(f"요약 생성 실패: {e}")
        return "요약 생성에 실패했습니다."


def create_visualization_suggestions(df, table_name="표", api_key=None, model=None):
    """표 데이터에 대한 시각화 방안을 제안합니다."""
    numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
    categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()

    viz_prompt = f"""
    다음 표의 데이터를 시각화하는 방법을 제안해주세요:

    표 이름: {table_name}
    열 목록: {list(df.columns)}
    숫자 열: {numeric_cols}
    범주형 열: {categorical_cols}
    데이터 샘플:
    {df.head(3).to_string()}

    제안사항:
    1. 적합한 차트 유형 (막대, 선, 산점도, 히트맵 등)
    2. 시각화할 주요 변수 조합
    3. 인사이트를 강조할 수 있는 방법
    4. Python 코드 예시 (matplotlib, seaborn, plotly 사용)
    """

    try:
        _model = model or get_gemini_model(api_key)
        response = _model.generate_content(
            viz_prompt,
            generation_config=genai.types.GenerationConfig(max_output_tokens=1500)
        )
        return _safe_response_text(response, "시각화 제안 생성에 실패했습니다.")

    except Exception as e:
        print(f"시각화 제안 생성 실패: {e}")
        return "시각화 제안 생성에 실패했습니다."


def analyze_pdf_tables_with_gemini(pdf_path, analysis_type="general", output_dir="./data/tables/", api_key=None):
    """PDF 표를 추출하고 Gemini로 분석하는 통합 함수."""
    os.makedirs(output_dir, exist_ok=True)

    print("PDF에서 표 추출 중...")
    try:
        dfs = extract_tables_from_pdf(pdf_path)
        if not dfs:
            print("추출된 표가 없습니다.")
            return None

        print(f"총 {len(dfs)}개의 표 발견")
        save_tables_to_csv(dfs, output_dir)

        _model = get_gemini_model(api_key)

        print("Gemini로 표 분석 중...")
        results = analyze_tables_batch(dfs, analysis_type, model=_model)

        if results:
            print("종합 요약 생성 중...")
            summary = generate_tables_summary(results, model=_model)

            visualization_suggestions = {}
            for table_name, result in results.items():
                visualization_suggestions[table_name] = create_visualization_suggestions(
                    result["dataframe"], table_name, model=_model
                )
                break  # 첫 번째 표만 시각화 제안

            return {
                "individual_analyses": results,
                "summary": summary,
                "visualization_suggestions": visualization_suggestions,
                "total_tables": len(dfs),
                "output_dir": output_dir
            }

    except Exception as e:
        print(f"표 분석 실패: {e}")
        return None


def create_table_insights_report(analysis_results, output_file="./data/table_insights_report.md"):
    """표 분석 결과를 마크다운 보고서로 저장합니다."""
    if not analysis_results:
        print("보고서 생성에 필요한 데이터가 없습니다.")
        return

    report_content = f"""# PDF 표 분석 보고서

## 분석 개요
- 총 표 개수: {analysis_results['total_tables']}
- 분석 유형: {list(analysis_results['individual_analyses'].values())[0]['type']}
- 분석 일시: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}

## 종합 요약
{analysis_results['summary']}

## 개별 표 분석 결과
"""

    for table_name, result in analysis_results['individual_analyses'].items():
        report_content += f"""
### {table_name}
**크기:** {result['row_count']}행 × {result['column_count']}열

#### 표 미리보기
```csv
{result['dataframe'].head().to_csv(index=False)}
```

#### Gemini 분석 결과
{result['analysis']}
"""

    if analysis_results.get('visualization_suggestions'):
        report_content += "\n## 시각화 제안\n"
        for table_name, suggestion in analysis_results['visualization_suggestions'].items():
            report_content += f"""
### {table_name} 시각화 제안
{suggestion}
"""

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(report_content)

    print(f"보고서가 {output_file}에 저장되었습니다.")


if __name__ == "__main__":
    import warnings, logging
    warnings.filterwarnings('ignore')
    logging.disable(logging.CRITICAL)
    if sys.platform == 'win32':
        os.system('chcp 65001 > nul')
    sys.stdout.reconfigure(encoding='utf-8')
    from pathlib import Path
    from dotenv import load_dotenv

    script_dir = Path(__file__).resolve().parent
    _env_path = script_dir.parent / ".env"
    if not _env_path.exists():
        print(f"[ERROR] .env 파일을 찾을 수 없습니다: {_env_path}")
        sys.exit(1)
    load_dotenv(_env_path, override=True)

    pdf_path = "../data/sample.pdf"
    print("=== PDF 표 Gemini 분석 시작 ===")

    results = analyze_pdf_tables_with_gemini(pdf_path, analysis_type="general")

    if results:
        print(f"\n총 {results['total_tables']}개의 표 분석 완료")

        print("\n=== 개별 표 분석 결과 ===")
        for table_name, analysis in results['individual_analyses'].items():
            text = analysis['analysis']
            print(f"\n{table_name}:")
            print(text[:300] + "..." if len(text) > 300 else text)

        print("\n=== 종합 요약 ===")
        print(results['summary'])

        create_table_insights_report(results)

    else:
        print("분석에 실패했습니다. .env 파일의 GOOGLE_API_KEY를 확인해주세요.")
